//
//  Session.swift
//  LabTunes
//
//  Created by markmota on 11/9/18.
//  Copyright © 2018 markmota. All rights reserved.
//

import Foundation
class Session: NSObject {
    var token: String?
    static let sharedInstance = Session()
    override private init(){
        super.init()
    }
    func saveSession(){
        token = "123456666"
    }
}

