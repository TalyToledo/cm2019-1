import UIKit

extension URL {
    func withQueries(_ queries: [String:String]) -> URL? {
        var components = URLComponents(url: self, resolvingAgainstBaseURL: true)
        components?.queryItems = queries.map{
            URLQueryItem(name: $0.0, value: $0.1)
        }
        return components?.url
    }
}

let baseurl = URL(string: "https://api.nasa.gov/planetary/apod")!

let query: [String:String] = ["api_key":"jQoiDGqQUmARwYfvnpBPuyjR4I4mm3rwRsoPaEKq","date":"2011-07-13"]

let urlFinal = baseurl.withQueries(query)!

struct NasaPhoto: Codable {
    var date: String
    var titulo: String
    var explanation: String
    var url: String
    
    enum CodingKeys: String,CodingKey{
        case date
        case titulo = "title"
        case explanation
        case url
    }
}

let task = URLSession.shared.dataTask(with: urlFinal) { (data, response, error) in
    if let data = data, let string = String(data: data, encoding: .utf8) {
        print(string)
    }
}

task.resume()
