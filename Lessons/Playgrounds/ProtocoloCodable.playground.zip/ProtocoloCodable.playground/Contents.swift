import UIKit

var str = "Hello, playground"

let jsonFromWeb = """
{
"firstName" : "Aketzally",
"lastName" : "Toledo",
"jobTitle" : "Student",
"phoneNumber" : "55-3434- 3334"
}
""".data(using: .utf8)!

struct Employee : Decodable, Encodable {
    var firstName : String
    var lastName : String
    var jobTitle : String
    var phoneNumnber : String
}
var resultMod: Employee
let jsonDecoder = JSONDecoder()
if let result = try? jsonDecoder.decode(Employee.self, from: jsonFromWeb){
    print (result)
    resultMod = result
    resultMod.firstName = "Ollin"
    print(resultMod)
    let myEncode = try JSONEncoder().encode(resultMod)
    print (myEncode)

}
else{
    print("Fallo el decode" )
}

